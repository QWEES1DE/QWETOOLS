namespace RobRunPotato;

/// <summary>Высокоуровневые операции с профилем драйвера для одного exe.</summary>
internal static class DriverProfile
{
    public const string OwnProfileName = "ROB RUN (Potato Slider)";
    public static string? LastProfileName { get; private set; }

    private static T WithSession<T>(Func<IntPtr, T> action)
    {
        NvApi.Initialize();
        IntPtr h = NvApi.CreateSession();
        try
        {
            NvApi.LoadSettings(h);
            return action(h);
        }
        finally { NvApi.DestroySession(h); }
    }

    /// <summary>Находит профиль exe. Если его нет, создаёт свой профиль и привязывает к нему exe.</summary>
    private static IntPtr GetOrCreateProfile(IntPtr h, string exeName, List<string> log)
    {
        IntPtr hProfile = NvApi.FindProfileForExe(h, exeName);
        if (hProfile != IntPtr.Zero)
        {
            log.Add($"{exeName} уже привязан к профилю «{NvApi.GetProfileName(h, hProfile)}» — меняем его.");
            return hProfile;
        }

        hProfile = NvApi.FindProfileByName(h, OwnProfileName);
        if (hProfile == IntPtr.Zero)
        {
            hProfile = NvApi.CreateProfile(h, OwnProfileName);
            log.Add($"Создан профиль «{OwnProfileName}».");
        }
        NvApi.AddApplication(h, hProfile, exeName, "ROB RUN");
        log.Add($"К профилю привязан {exeName}.");
        return hProfile;
    }

    /// <summary>Строит итоговый список значений для пресета (с учётом своего LOD bias).</summary>
    public static Dictionary<uint, uint> BuildValues(Preset preset, double? customLod)
    {
        var values = new Dictionary<uint, uint>(preset.Settings);
        double? lod = customLod ?? preset.Lod;
        if (lod is double l)
        {
            values[NvSetting.LodBias] = NvSetting.LodToRaw(l);
            values[NvSetting.DriverControlledLod] = 0;
            // при отрицательном LOD («резкость») драйвер не должен его обрезать
            values[NvSetting.NegativeLodBias] = l < 0 ? 0u : 1u;
            // Без «Transparency Supersampling» драйвер часто игнорирует LOD Bias (DX).
            // Без MSAA он ничего не стоит по производительности.
            values[NvSetting.TrSupersampling] = 0x8;
        }
        return values;
    }

    public static List<string> Apply(string exeName, Preset preset, double? customLod)
    {
        var log = new List<string>();
        WithSession(h =>
        {
            IntPtr hProfile = GetOrCreateProfile(h, exeName, log);
            var values = BuildValues(preset, customLod);

            // Сначала сбрасываем всё, что мы когда-либо трогаем, чтобы уровни не «накладывались».
            foreach (uint id in NvSetting.All)
                if (!values.ContainsKey(id))
                    NvApi.Restore(h, hProfile, id);

            foreach (var (id, v) in values)
            {
                NvApi.SetDword(h, hProfile, id, v);
                log.Add($"  {NvSetting.Name(id)} = {NvSetting.Describe(id, v)}");
            }

            NvApi.SaveSettings(h);
            log.Add(values.Count == 0
                ? "Все настройки возвращены к стандартным."
                : "Сохранено в драйвер. Перезапустите игру!");
            return 0;
        });
        return log;
    }

    /// <summary>Текущие значения настроек в профиле exe (только те, что заданы).</summary>
    public static Dictionary<uint, uint>? ReadCurrent(string exeName)
    {
        return WithSession<Dictionary<uint, uint>?>(h =>
        {
            IntPtr hProfile = NvApi.FindProfileForExe(h, exeName);
            if (hProfile == IntPtr.Zero) return null;
            LastProfileName = NvApi.GetProfileName(h, hProfile);
            var result = new Dictionary<uint, uint>();
            foreach (uint id in NvSetting.All)
                if (NvApi.GetDword(h, hProfile, id) is uint v)
                    result[id] = v;
            return result;
        });
    }
}
